import "./App.css";
import Navbar from "./Navbar";

function blueprint() {
	return (
		<div>
			<Navbar />
		</div>
	);
}

export default blueprint;
